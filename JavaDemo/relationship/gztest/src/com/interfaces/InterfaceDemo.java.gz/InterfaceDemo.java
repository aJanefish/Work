package com.interfaces;

/**
 * 抽象类是定义这个对象是什么
 * 接口是定义这个对象能做什么
 * */

public class InterfaceDemo {
}
