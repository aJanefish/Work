package com.mode.factory;

public class FactoryMethodRuntimeException extends Throwable {

    public FactoryMethodRuntimeException() {
    }
}
