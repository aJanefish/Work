package com.mode.factory;

public abstract class Product {

    public abstract void use();
}
