package com.test;

import com.utils.P;

public class Test01 {
    static {
        P.pln("Hello world!");
        System.exit(0);
    }
}
