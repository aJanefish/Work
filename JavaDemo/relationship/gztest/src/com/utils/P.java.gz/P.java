package com.utils;

public class P {
    public static void pln(Object object){
        System.out.println(object);
    }

    public static void p(Object object){
        System.out.print(object);
    }
    public static void pln(){
        pln("");
    }
}

