package com;

public class StringDemo {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer("ss");
        String string = new String("");
        StringBuilder stringBuilder = new StringBuilder("ss");

    }
}
