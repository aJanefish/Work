package com.stream;



public class JoinDemo {
    public static void main(String args[]){
        Parent parent = new Parent();
        parent.start();
    }
}
